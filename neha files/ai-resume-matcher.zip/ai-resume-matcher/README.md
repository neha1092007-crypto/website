# AI Resume Matcher - Hackathon Prototype

## Run on Replit
1. Create a new Node.js Repl and upload these files (or import the zip).
2. Click **Run**. The app opens in the webview.
3. Optional AI mode: Tools > Secrets > add `ANTHROPIC_API_KEY`. The badge in the header changes to "AI mode".

Without a key the app uses a built-in rule-based engine, so the demo always works.

## How it works
- `public/index.html`: UI plus the `analyzeResume()` engine (scores, keywords, ATS checks).
- `server.js`: serves the UI and `POST /api/insights`, which asks the model for honest, personalized suggestions. The key never reaches the browser.
- Scores: Overall = 0.40 Skills + 0.20 Keywords + 0.15 Experience + 0.10 Education + 0.15 ATS.

## Limits
Scanned (image) PDFs are not supported. Paste the text instead. Resumes are never stored.

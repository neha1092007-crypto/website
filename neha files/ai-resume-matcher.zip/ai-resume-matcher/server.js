// AI Resume Matcher - server. Keeps API keys on the server (Replit Secrets).
// Add a secret named ANTHROPIC_API_KEY (Tools > Secrets) to enable AI suggestions.
// Without it the app still works fully using the built-in demo engine.
const express = require('express');
const path = require('path');
const app = express();
const KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-6';

app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/health', (_req, res) => res.json({ status: 'ok', mode: KEY ? 'ai' : 'mock' }));

app.post('/api/insights', async (req, res) => {
  if (!KEY) return res.status(501).json({ error: 'No API key configured' });
  const { resumeText, jobDescription, jobTitle, missing = [], matched = [] } = req.body || {};
  if (typeof resumeText !== 'string' || typeof jobDescription !== 'string' ||
      resumeText.length < 50 || jobDescription.length < 50) {
    return res.status(400).json({ error: 'resumeText and jobDescription are required' });
  }
  const system = 'You are a careful resume coach. Respond with JSON only, no markdown. ' +
    'NEVER invent or suggest inventing skills, experience, certifications or achievements. ' +
    'Only recommend adding information the candidate genuinely has, or learning a skill.';
  const user = `Job title: ${jobTitle || 'n/a'}
Matched skills: ${matched.join(', ') || 'none'}
Missing skills: ${missing.join(', ') || 'none'}

RESUME:
${resumeText.slice(0, 8000)}

JOB DESCRIPTION:
${jobDescription.slice(0, 8000)}

Return JSON: {"summary": "2 sentence assessment", "suggestions": [{"t": "short title", "d": "specific actionable advice", "p": "High|Medium|Low"}]} with 4 to 7 suggestions.`;
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: MODEL, max_tokens: 1200, system, messages: [{ role: 'user', content: user }] }),
      signal: AbortSignal.timeout(20000)
    });
    if (!r.ok) throw new Error('Upstream ' + r.status);
    const data = await r.json();
    const text = (data.content || []).map(c => c.text || '').join('').replace(/```json|```/g, '').trim();
    const out = JSON.parse(text);
    const suggestions = (out.suggestions || []).slice(0, 8).map(s => ({
      t: String(s.t || '').slice(0, 120), d: String(s.d || '').slice(0, 500),
      p: ['High', 'Medium', 'Low'].includes(s.p) ? s.p : 'Medium'
    })).filter(s => s.t && s.d);
    if (!suggestions.length) throw new Error('Empty result');
    res.json({ summary: String(out.summary || '').slice(0, 400), suggestions });
  } catch (e) {
    console.error('insights failed:', e.message); // never log resume text
    res.status(502).json({ error: 'AI unavailable' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => console.log('AI Resume Matcher running on port ' + PORT));
